# Archived unused views (2026-07-02)

These files were unreferenced anywhere in the app at archival time and were
removed from the live tree during the code audit. They are kept here (and in
`archive/unused-20260702.tar.gz`) as a backup in case any are needed later.

- `resources/views/bio/edit.blade.php` + `resources/views/bio/partials/*`
  A superseded/half-migrated bio editor. The live editor is
  `resources/views/bio/editor/index.blade.php` (the `bio.edit` route renders it).
- `resources/views/bio/maintenance.blade.php`,
  `resources/views/bio/public-maintenance.blade.php`
  Maintenance placeholder views with no route/controller/include referencing them.

To restore a file: copy it from this folder back to its original path.
